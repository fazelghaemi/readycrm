<?php
require_once __DIR__ . '/config.php';

// ═══════════════════════════════════════════════════════════════════════════════
// توابع نمایش پیام
// ═══════════════════════════════════════════════════════════════════════════════

function displayMessage($type = '') {
    $messages = ['success_message', 'error_message', 'warning_message', 'info_message'];
    $output = '';

    foreach ($messages as $message_type) {
        if (isset($_SESSION[$message_type])) {
            $class = str_replace('_message', '', $message_type);
            $icon = getMessageIcon($class);

            $alert_class = $class === 'error' ? 'danger' : $class;
            $output .= '<div class="alert alert-' . $alert_class . ' alert-dismissible fade show" role="alert">';
            $output .= '<i class="' . $icon . ' me-2"></i>';
            $output .= $_SESSION[$message_type];
            $output .= '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>';
            $output .= '</div>';

            unset($_SESSION[$message_type]);
        }
    }

    return $output;
}

function getMessageIcon($type) {
    $icons = [
        'success' => 'fas fa-check-circle',
        'error' => 'fas fa-times-circle',
        'warning' => 'fas fa-exclamation-triangle',
        'info' => 'fas fa-info-circle'
    ];

    return $icons[$type] ?? 'fas fa-info-circle';
}

function setMessage($message, $type = 'success') {
    $_SESSION[$type . '_message'] = $message;
}

// ═══════════════════════════════════════════════════════════════════════════════
// توابع بازیابی رمز عبور
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * تولید CSRF Token
 */
function generateCSRFToken() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

/**
 * اعتبارسنجی CSRF Token
 */
function verifyCSRFToken($token) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $token);
}

/**
 * ایجاد توکن بازیابی رمز عبور
 */
function createPasswordResetToken($user_id, $email) {
    global $conn;

    try {
        // تولید توکن امن
        $token = bin2hex(random_bytes(32));

        // محاسبه زمان انقضا
        $expires_at = date('Y-m-d H:i:s', time() + PASSWORD_RESET_TOKEN_EXPIRY);

        // حذف توکن‌های قبلی این کاربر
        $stmt = $conn->prepare("DELETE FROM password_reset_tokens WHERE user_id = ? OR email = ?");
        $stmt->execute([$user_id, $email]);

        // ذخیره توکن جدید
        $stmt = $conn->prepare("
            INSERT INTO password_reset_tokens (user_id, email, token, expires_at, ip_address, user_agent)
            VALUES (?, ?, ?, ?, ?, ?)
        ");
        
        $ip = getRealIpAddr();
        $user_agent = $_SERVER['HTTP_USER_AGENT'] ?? '';
        
        $stmt->execute([$user_id, $email, $token, $expires_at, $ip, $user_agent]);

        return [
            'success' => true,
            'token' => $token
        ];

    } catch (Exception $e) {
        logError('Password reset token creation failed: ' . $e->getMessage());
        return ['success' => false, 'message' => 'خطای سیستمی'];
    }
}

/**
 * بررسی اعتبار توکن بازیابی
 */
function verifyPasswordResetToken($token) {
    global $conn;

    try {
        $stmt = $conn->prepare("
            SELECT id, user_id, email, expires_at, is_used
            FROM password_reset_tokens
            WHERE token = ?
            AND is_used = FALSE
        ");
        $stmt->execute([$token]);
        $data = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$data) {
            return ['success' => false, 'message' => 'توکن نامعتبر یا استفاده شده است'];
        }

        // بررسی انقضا
        if (strtotime($data['expires_at']) < time()) {
            return ['success' => false, 'message' => 'توکن منقضی شده است'];
        }

        return [
            'success' => true,
            'user_id' => $data['user_id'],
            'email' => $data['email'],
            'token_id' => $data['id']
        ];

    } catch (Exception $e) {
        logError('Token verification failed: ' . $e->getMessage());
        return ['success' => false, 'message' => 'خطای سیستمی'];
    }
}

/**
 * علامت‌گذاری توکن به عنوان استفاده شده
 */
function markTokenAsUsed($token) {
    global $conn;

    try {
        $stmt = $conn->prepare("
            UPDATE password_reset_tokens
            SET is_used = TRUE, used_at = NOW()
            WHERE token = ?
        ");
        return $stmt->execute([$token]);

    } catch (Exception $e) {
        logError('Mark token as used failed: ' . $e->getMessage());
        return false;
    }
}

/**
 * تغییر رمز عبور با توکن
 */
function resetPasswordWithToken($token, $new_password) {
    global $conn;

    // بررسی توکن
    $verify = verifyPasswordResetToken($token);
    if (!$verify['success']) {
        return $verify;
    }

    try {
        // هش کردن رمز جدید
        $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

        // بروزرسانی رمز کاربر
        $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
        $stmt->execute([$hashed_password, $verify['user_id']]);

        // علامت‌گذاری توکن
        markTokenAsUsed($token);

        // لاگ فعالیت
        logActivity("Password reset completed for user ID: " . $verify['user_id']);

        return ['success' => true, 'message' => 'رمز عبور با موفقیت تغییر کرد'];

    } catch (Exception $e) {
        logError('Password reset failed: ' . $e->getMessage());
        return ['success' => false, 'message' => 'خطای سیستمی'];
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// توابع ارسال ایمیل
// ═══════════════════════════════════════════════════════════════════════════════

/**
 * ارسال ایمیل ساده با mail()
 */
function sendEmail($to, $subject, $body, $is_html = true) {
    try {
        $headers  = "MIME-Version: 1.0\r\n";
        $headers .= "Content-type: text/html; charset=UTF-8\r\n";
        $headers .= "From: " . MAIL_FROM_NAME . " <" . MAIL_FROM_EMAIL . ">\r\n";
        $headers .= "Reply-To: " . MAIL_FROM_EMAIL . "\r\n";
        $headers .= "X-Mailer: PHP/" . phpversion() . "\r\n";
        
        $result = mail($to, $subject, $body, $headers);
        
        logEmail($to, $subject, $result ? 'success' : 'failed');
        
        return [
            'success' => $result,
            'message' => $result ? 'ایمیل ارسال شد' : 'خطا در ارسال ایمیل'
        ];
        
    } catch (Exception $e) {
        logEmail($to, $subject, 'error', $e->getMessage());
        return [
            'success' => false,
            'message' => $e->getMessage()
        ];
    }
}

/**
 * قالب HTML ایمیل بازیابی رمز
 */
function getPasswordResetEmailTemplate($reset_link, $user_name = '') {
    $expiry_minutes = PASSWORD_RESET_TOKEN_EXPIRY / 60;

    return '
    <!DOCTYPE html>
    <html lang="fa" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <style>
            body {
                font-family: Tahoma, Arial, sans-serif;
                background-color: #f4f4f4;
                margin: 0;
                padding: 0;
            }
            .container {
                max-width: 600px;
                margin: 40px auto;
                background: white;
                border-radius: 12px;
                overflow: hidden;
                box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            }
            .header {
                background: linear-gradient(135deg, #1dd3b0 0%, #17b89a 100%);
                color: white;
                padding: 30px 20px;
                text-align: center;
            }
            .header h1 {
                margin: 0;
                font-size: 24px;
            }
            .content {
                padding: 40px 30px;
                line-height: 1.8;
                color: #333;
            }
            .content p {
                margin: 0 0 20px;
            }
            .btn {
                display: inline-block;
                background: #1dd3b0;
                color: white;
                padding: 14px 40px;
                text-decoration: none;
                border-radius: 8px;
                margin: 20px 0;
                font-weight: bold;
            }
            .btn:hover {
                background: #17b89a;
            }
            .warning {
                background: #fff3cd;
                border-right: 4px solid #ffc107;
                padding: 15px;
                margin: 20px 0;
                border-radius: 4px;
            }
            .footer {
                background: #f8f9fa;
                padding: 20px;
                text-align: center;
                font-size: 13px;
                color: #666;
                border-top: 1px solid #e9ecef;
            }
        </style>
    </head>
    <body>
        <div class="container">
            <div class="header">
                <h1>🔐 بازیابی رمز عبور</h1>
            </div>
            <div class="content">
                <p>سلام' . ($user_name ? ' ' . $user_name : '') . '،</p>
                <p>درخواستی برای بازیابی رمز عبور حساب کاربری شما دریافت شده است.</p>
                <p>برای تنظیم رمز عبور جدید، روی دکمه زیر کلیک کنید:</p>

                <p style="text-align: center;">
                    <a href="' . $reset_link . '" class="btn">بازیابی رمز عبور</a>
                </p>

                <div class="warning">
                    <strong>⚠️ توجه:</strong> این لینک تنها به مدت ' . $expiry_minutes . ' دقیقه معتبر است.
                </div>

                <p>اگر شما این درخواست را ارسال نکرده‌اید، لطفاً این ایمیل را نادیده بگیرید.</p>

                <p style="font-size: 12px; color: #888; margin-top: 30px;">
                    اگر دکمه بالا کار نمی‌کند، لینک زیر را در مرورگر خود کپی کنید:<br>
                    <a href="' . $reset_link . '" style="color: #1dd3b0; word-break: break-all;">' . $reset_link . '</a>
                </p>
            </div>
            <div class="footer">
                <p>این ایمیل توسط سیستم ' . APP_NAME . ' ارسال شده است.</p>
                <p>© ' . date('Y') . ' تمامی حقوق محفوظ است.</p>
            </div>
        </div>
    </body>
    </html>
    ';
}

// ═══════════════════════════════════════════════════════════════════════════════
// توابع تاریخ و زمان
// ═══════════════════════════════════════════════════════════════════════════════

function formatPersianDate($date, $format = 'Y/m/d H:i') {
    if (!$date) return '-';
    $timestamp = is_numeric($date) ? $date : strtotime($date);
    return jdate($format, $timestamp);
}

function jdate($format, $timestamp = '') {
    $timestamp = $timestamp ? $timestamp : time();

    $jy = $jm = $jd = 0;
    gregorian_to_jalali(date('Y', $timestamp), date('m', $timestamp), date('d', $timestamp), $jy, $jm, $jd);

    $persian_months = [
        1 => 'فروردین', 2 => 'اردیبهشت', 3 => 'خرداد',
        4 => 'تیر', 5 => 'مرداد', 6 => 'شهریور',
        7 => 'مهر', 8 => 'آبان', 9 => 'آذر',
        10 => 'دی', 11 => 'بهمن', 12 => 'اسفند'
    ];

    $month_name = $persian_months[$jm];

    $format = str_replace(['Y', 'M', 'm', 'd', 'H', 'i', 's'],
                         [$jy, $month_name, sprintf('%02d', $jm), sprintf('%02d', $jd),
                          date('H', $timestamp), date('i', $timestamp), date('s', $timestamp)], $format);

    return $format;
}

function convertToJalaliForChart($gregorian_date) {
    $timestamp = strtotime($gregorian_date);
    $jy = $jm = $jd = 0;
    gregorian_to_jalali(date('Y', $timestamp), date('m', $timestamp), date('d', $timestamp), $jy, $jm, $jd);

    $persian_months = [
        1 => 'فروردین', 2 => 'اردیبهشت', 3 => 'خرداد',
        4 => 'تیر', 5 => 'مرداد', 6 => 'شهریور',
        7 => 'مهر', 8 => 'آبان', 9 => 'آذر',
        10 => 'دی', 11 => 'بهمن', 12 => 'اسفند'
    ];

    return $persian_months[$jm] . ' ' . $jy;
}

function gregorian_to_jalali($gy, $gm, $gd, &$jy, &$jm, &$jd) {
    $g_d_m = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];

    if ($gy <= 1600) {
        $jy = 0;
        $gy -= 621;
    } else {
        $jy = 979;
        $gy -= 1600;
    }

    if ($gm > 2) {
        $gy2 = $gy + 1;
    } else {
        $gy2 = $gy;
    }

    $days = (365 * $gy) + ((int)(($gy2 + 3) / 4)) - ((int)(($gy2 + 99) / 100)) +
            ((int)(($gy2 + 399) / 400)) - 80 + $gd + $g_d_m[$gm - 1];

    $jy += 33 * ((int)($days / 12053));
    $days %= 12053;

    $jy += 4 * ((int)($days / 1461));
    $days %= 1461;

    if ($days > 365) {
        $jy += (int)(($days - 1) / 365);
        $days = ($days - 1) % 365;
    }

    if ($days < 186) {
        $jm = 1 + (int)($days / 31);
        $jd = 1 + ($days % 31);
    } else {
        $jm = 7 + (int)(($days - 186) / 30);
        $jd = 1 + (($days - 186) % 30);
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// توابع فرمت‌دهی
// ═══════════════════════════════════════════════════════════════════════════════

function formatMoney($amount, $currency = CURRENCY) {
    return number_format($amount, 0, '.', ',') . ' ' . $currency;
}

function formatPhone($phone) {
    if (!$phone) return '-';

    $phone = preg_replace('/\D/', '', $phone);

    if (strlen($phone) == 11 && substr($phone, 0, 2) == '09') {
        return substr($phone, 0, 4) . '-' . substr($phone, 4, 3) . '-' . substr($phone, 7);
    } elseif (strlen($phone) == 11 && substr($phone, 0, 3) == '021') {
        return substr($phone, 0, 3) . '-' . substr($phone, 3, 4) . '-' . substr($phone, 7);
    }

    return $phone;
}

function truncateText($text, $length = 100, $suffix = '...') {
    if (mb_strlen($text, 'UTF-8') <= $length) {
        return $text;
    }

    return mb_substr($text, 0, $length, 'UTF-8') . $suffix;
}

function generateUniqueCode($prefix = '', $length = 8) {
    $characters = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    $code = $prefix;

    for ($i = 0; $i < $length; $i++) {
        $code .= $characters[rand(0, strlen($characters) - 1)];
    }

    return $code;
}

// ═══════════════════════════════════════════════════════════════════════════════
// توابع فایل
// ═══════════════════════════════════════════════════════════════════════════════

function isValidFileType($filename, $allowed_types = UPLOAD_ALLOWED_TYPES) {
    $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
    return in_array($extension, $allowed_types);
}

function isValidFileSize($file_size, $max_size = UPLOAD_MAX_SIZE) {
    return $file_size <= $max_size;
}

function uploadFile($file, $upload_path = UPLOAD_PATH, $allowed_types = UPLOAD_ALLOWED_TYPES) {
    if (!isset($file['tmp_name']) || empty($file['tmp_name'])) {
        return ['success' => false, 'message' => 'فایلی انتخاب نشده است'];
    }

    if ($file['error'] !== UPLOAD_ERR_OK) {
        return ['success' => false, 'message' => 'خطا در آپلود فایل'];
    }

    if (!isValidFileType($file['name'], $allowed_types)) {
        return ['success' => false, 'message' => 'فرمت فایل مجاز نیست'];
    }

    if (!isValidFileSize($file['size'])) {
        return ['success' => false, 'message' => 'اندازه فایل بیش از حد مجاز است'];
    }

    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $filename = uniqid() . '.' . $extension;
    $full_path = $upload_path . $filename;

    if (!is_dir($upload_path)) {
        mkdir($upload_path, 0755, true);
    }

    if (move_uploaded_file($file['tmp_name'], $full_path)) {
        return [
            'success' => true,
            'filename' => $filename,
            'path' => $full_path,
            'original_name' => $file['name']
        ];
    }

    return ['success' => false, 'message' => 'خطا در ذخیره فایل'];
}

function deleteFile($file_path) {
    if (file_exists($file_path)) {
        return unlink($file_path);
    }
    return false;
}

function formatFileSize($bytes) {
    $units = ['بایت', 'کیلوبایت', 'مگابایت', 'گیگابایت'];

    for ($i = 0; $bytes > 1024 && $i < count($units) - 1; $i++) {
        $bytes /= 1024;
    }

    return round($bytes, 2) . ' ' . $units[$i];
}

// ═══════════════════════════════════════════════════════════════════════════════
// توابع صفحه‌بندی و UI
// ═══════════════════════════════════════════════════════════════════════════════

function createPagination($current_page, $total_records, $records_per_page, $base_url) {
    $total_pages = ceil($total_records / $records_per_page);

    if ($total_pages <= 1) return '';

    $output = '<nav aria-label="صفحه‌بندی">';
    $output .= '<ul class="pagination justify-content-center">';

    if ($current_page > 1) {
        $output .= '<li class="page-item">';
        $output .= '<a class="page-link" href="' . $base_url . '&page=' . ($current_page - 1) . '">قبلی</a>';
        $output .= '</li>';
    }

    $start = max(1, $current_page - 2);
    $end = min($total_pages, $current_page + 2);

    for ($i = $start; $i <= $end; $i++) {
        $active = ($i == $current_page) ? ' active' : '';
        $output .= '<li class="page-item' . $active . '">';
        $output .= '<a class="page-link" href="' . $base_url . '&page=' . $i . '">' . $i . '</a>';
        $output .= '</li>';
    }

    if ($current_page < $total_pages) {
        $output .= '<li class="page-item">';
        $output .= '<a class="page-link" href="' . $base_url . '&page=' . ($current_page + 1) . '">بعدی</a>';
        $output .= '</li>';
    }

    $output .= '</ul>';
    $output .= '</nav>';

    return $output;
}

function generateRandomColor() {
    return '#' . str_pad(dechex(mt_rand(0, 0xFFFFFF)), 6, '0', STR_PAD_LEFT);
}

// ═══════════════════════════════════════════════════════════════════════════════
// توابع ترجمه و تبدیل
// ═══════════════════════════════════════════════════════════════════════════════

function getRoleTitle($role) {
    $roles = [
        'admin' => 'مدیر کل',
        'manager' => 'مدیر',
        'sales' => 'فروشنده',
        'user' => 'کاربر'
    ];

    return $roles[$role] ?? $role;
}

function getStatusTitle($status, $type = 'general') {
    $statuses = [
        'general' => [
            'active' => 'فعال',
            'inactive' => 'غیرفعال',
            'pending' => 'در انتظار',
            'suspended' => 'تعلیق شده',
            'completed' => 'تکمیل شده',
            'cancelled' => 'لغو شده',
            'confirmed' => 'تایید شده',
            'processing' => 'در حال پردازش',
            'shipped' => 'ارسال شده',
            'delivered' => 'تحویل داده شده',
            'draft' => 'پیش‌نویس',
            'discontinued' => 'متوقف شده'
        ],
        'lead' => [
            'new' => 'جدید',
            'contacted' => 'تماس گرفته شده',
            'qualified' => 'واجد شرایط',
            'proposal' => 'پیشنهاد ارسال شده',
            'negotiation' => 'در حال مذاکره',
            'won' => 'موفق',
            'lost' => 'از دست رفته'
        ],
        'task' => [
            'pending' => 'در انتظار',
            'in_progress' => 'در حال انجام',
            'completed' => 'تکمیل شده',
            'cancelled' => 'لغو شده'
        ],
        'user' => [
            'active' => 'فعال',
            'inactive' => 'غیرفعال',
            'suspended' => 'معلق'
        ],
        'product' => [
            'active' => 'فعال',
            'inactive' => 'غیرفعال',
            'discontinued' => 'متوقف شده'
        ]
    ];

    return $statuses[$type][$status] ?? $statuses['general'][$status] ?? $status;
}

function getPriorityTitle($priority) {
    $priorities = [
        'low' => 'کم',
        'medium' => 'متوسط',
        'high' => 'بالا',
        'urgent' => 'فوری'
    ];

    return $priorities[$priority] ?? $priority;
}

function getStatusClass($status, $type = 'general') {
    $classes = [
        'general' => [
            'active' => 'success',
            'inactive' => 'secondary',
            'pending' => 'warning',
            'suspended' => 'danger'
        ],
        'lead' => [
            'new' => 'primary',
            'contacted' => 'info',
            'qualified' => 'warning',
            'proposal' => 'secondary',
            'negotiation' => 'dark',
            'won' => 'success',
            'lost' => 'danger'
        ]
    ];

    return $classes[$type][$status] ?? 'secondary';
}

function getPriorityClass($priority) {
    $classes = [
        'low' => 'success',
        'medium' => 'warning',
        'high' => 'danger',
        'urgent' => 'dark'
    ];

    return $classes[$priority] ?? 'secondary';
}

function getActionClass($action) {
    return match(true) {
        str_contains($action, 'create') => 'success',
        str_contains($action, 'update') => 'warning',
        str_contains($action, 'delete') => 'danger',
        str_contains($action, 'login') => 'info',
        default => 'secondary'
    };
}

function getActionTitle($action) {
    $actions = [
        'login' => 'ورود',
        'logout' => 'خروج',
        'create_customer' => 'ایجاد مشتری',
        'update_customer' => 'بروزرسانی مشتری',
        'delete_customer' => 'حذف مشتری',
        'create_lead' => 'ایجاد لید',
        'update_lead' => 'بروزرسانی لید',
        'delete_lead' => 'حذف لید',
        'create_task' => 'ایجاد وظیفه',
        'update_task' => 'بروزرسانی وظیفه',
        'delete_task' => 'حذف وظیفه',
        'create_sale' => 'ایجاد فروش',
        'update_sale' => 'بروزرسانی فروش',
        'delete_sale' => 'حذف فروش',
        'create_product' => 'ایجاد محصول',
        'update_product' => 'بروزرسانی محصول',
        'delete_product' => 'حذف محصول',
        'create_user' => 'ایجاد کاربر',
        'update_user' => 'بروزرسانی کاربر',
        'delete_user' => 'حذف کاربر'
    ];
    return $actions[$action] ?? $action;
}

function getTableTitle($table) {
    $tables = [
        'customers' => 'مشتریان',
        'leads' => 'لیدها',
        'tasks' => 'وظایف',
        'sales' => 'فروش‌ها',
        'products' => 'محصولات',
        'users' => 'کاربران'
    ];
    return $tables[$table] ?? $table;
}

function getRoleClass($role) {
    return match($role) {
        'admin' => 'danger',
        'manager' => 'warning',
        'sales' => 'success',
        'user' => 'info',
        default => 'secondary'
    };
}

// ═══════════════════════════════════════════════════════════════════════════════
// توابع امنیتی و کمکی
// ═══════════════════════════════════════════════════════════════════════════════

function buildUrl($base_url, $new_params = []) {
    $current_params = $_GET;
    $params = array_merge($current_params, $new_params);

    $query_string = http_build_query($params);
    return $base_url . ($query_string ? '?' . $query_string : '');
}

function cleanUrl($url) {
    return filter_var($url, FILTER_SANITIZE_URL);
}

function getRealIpAddr() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }
    return $ip;
}

function base64UrlEncode($data) {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function base64UrlDecode($data) {
    return base64_decode(str_pad(strtr($data, '-_', '+/'), strlen($data) % 4, '=', STR_PAD_RIGHT));
}
?>
